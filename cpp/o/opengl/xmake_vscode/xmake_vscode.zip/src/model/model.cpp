#include "deps.h"

#include "model.h"
#include "shader.h"
#include "texture.h"
#include "mash.h"
#include "renderer.h"
#include "render_context.h"


Model::Model(const MashPtr &mash, const ShaderPtr &shader, const TexturePtr &texture)
    : mMash{ mash }, mShader{ shader }, mTexture{ texture } {
    if(nullptr == mShader) {
        return;
    }
    if(nullptr == mTexture || !mTexture->valid()) {
        return;
    }
    mShader->get("useTexture").set(true);
    mShader->get("defTexture").set(0);
}

Model& Model::mash(const MashPtr &mash) {
    mMash = mash;
    return *this;
}

Model& Model::shader(const ShaderPtr &shader) {
    mShader = shader;
    return *this;
}

Model& Model::texture(const TexturePtr &texture) {
    mTexture = texture;
    return *this;
}

const MashPtr Model::mash() const {
    return mMash;
}

const ShaderPtr Model::shader() const {
    return mShader;
}

const TexturePtr Model::texture() const {
    return mTexture;
}

void Model::draw(Renderer &renderer, const RenderContext &rContext) const {
    if(nullptr == mMash) {
        return;
    }
    renderer.bind(this);

    RenderContext ctx{ rContext };

    ctx.mode = RenderContext::RenderMode::Triangles;
    if(mMash->hasIndices()) {
        ctx.method = RenderContext::RenderMethod::Elements;
        ctx["count"] = static_cast<GLsizei>(mMash->indices());
    } else {
        ctx.method = RenderContext::RenderMethod::Arrays;
        ctx["count"] = static_cast<GLsizei>(mMash->vertices());
    }

    renderer.draw(ctx);
}

void Model::bind() const {
    if(mShader) mShader->use();
    if(mMash) mMash->bind();
    if(mTexture) mTexture->bind();
}

void Model::configure(RenderContext &) const {}
