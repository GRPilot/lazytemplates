#pragma once

#include "render_object.h"

class Mash;
class Shader;
class Texture;

namespace {
using MashPtr = std::shared_ptr<Mash>;
using ShaderPtr = std::shared_ptr<Shader>;
using TexturePtr = std::shared_ptr<Texture>;
}

class Model : public RenderObject {
public:
    Model() = default;
    Model(const MashPtr &mash,
          const ShaderPtr &shader,
          const TexturePtr &texture);

    Model &mash(const MashPtr &mash);
    Model &shader(const ShaderPtr &shader);
    Model &texture(const TexturePtr &texture);

    const MashPtr mash() const;
    const ShaderPtr shader() const;
    const TexturePtr texture() const;

    void draw(Renderer &renderer, const RenderContext &rContext) const override;

protected:
    void bind() const override;
    void configure(RenderContext &ctx) const override;

private:
    MashPtr mMash;
    ShaderPtr mShader;
    TexturePtr mTexture;
};
