#pragma once

class RenderObject;
class RenderContext;

namespace {
using RenderContextPtr = std::shared_ptr<RenderContext>;
}

class Renderer {
public:
    Renderer();

    void bind(const RenderObject *object) const;
    void draw(const RenderContext &ctx) const;
    void configure(const RenderObject *object) const;

    RenderContextPtr context();
    const RenderContextPtr context() const;

private:
    RenderContextPtr mCtx;
};
