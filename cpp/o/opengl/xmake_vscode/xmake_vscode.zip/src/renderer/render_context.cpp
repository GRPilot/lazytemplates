#include "deps.h"

#include "render_context.h"


std::any &RenderContext::operator[](std::string_view property) {
    assert(!property.empty());
    return mData[property];
}

const std::any& RenderContext::operator[](std::string_view property) const {
    assert(!property.empty());
    return mData.at(property);
}

bool RenderContext::has(std::string_view property) const {
    return mData.end() != mData.find(property);
}

void RenderContext::remove(std::string_view property) {
    mData.erase(property);
}
