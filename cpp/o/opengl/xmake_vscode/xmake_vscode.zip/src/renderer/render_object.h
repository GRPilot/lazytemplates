#pragma once

class RenderContext;

class RenderObject {
    friend class Renderer;
public:
    virtual ~RenderObject() = default;
    virtual void draw(Renderer &renderer, const RenderContext &rContext) const = 0;

protected:
    virtual void bind() const = 0;
    virtual void configure(RenderContext &ctx) const = 0;
};
