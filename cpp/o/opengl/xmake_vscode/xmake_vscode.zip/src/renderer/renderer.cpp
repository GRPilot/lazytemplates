#include "deps.h"

#include "renderer.h"
#include "render_object.h"
#include "render_context.h"

Renderer::Renderer()
    : mCtx{ std::make_shared<RenderContext>() } {
    mCtx->state = RenderContext::State::Enabled;
}

void Renderer::bind(const RenderObject *object) const {
    if(RenderContext::State::Disabled == mCtx->state) {
        return;
    }

    if(nullptr != object) {
        object->bind();
    }
}

void Renderer::draw(const RenderContext &ctx) const {
    if(RenderContext::State::Disabled == mCtx->state) {
        return;
    }

    GLsizei count{ ctx.has("count") ? std::any_cast<GLsizei>(ctx["count"]) : 0 };
    GLenum mode{ static_cast<GLenum>(ctx.mode) };

    switch(ctx.method) {
        case RenderContext::RenderMethod::Arrays:
            glDrawArrays(mode, 0, count);
            break;

        case RenderContext::RenderMethod::Elements:
            glDrawElements(mode, count, GL_UNSIGNED_INT, nullptr);
            break;

        default:
            return;
    }
}

void Renderer::configure(const RenderObject *object) const {
    if(nullptr != object) {
        object->configure(*mCtx);
    }
}

RenderContextPtr Renderer::context() {
    return mCtx;
}

const RenderContextPtr Renderer::context() const {
    return mCtx;
}
