#pragma once

class RenderContext {
public:
    enum class State {
        Enabled,
        Disabled,
    };

    enum class RenderMethod : GLenum {
        Elements,
        Arrays,
    };

    enum class RenderMode : GLenum {
        Points         = GL_POINTS,
        Lines          = GL_LINES,
        LineLoop       = GL_LINE_LOOP,
        LineStrip      = GL_LINE_STRIP,
        Triangles      = GL_TRIANGLES,
        TriangleStrip  = GL_TRIANGLE_STRIP,
        TriangleFan    = GL_TRIANGLE_FAN,
    };

    State state{ State::Disabled };
    RenderMethod method{ RenderMethod::Arrays };
    RenderMode mode{ RenderMode::Triangles };

    std::any &operator[](std::string_view property);
    const std::any &operator[](std::string_view property) const;

    bool has(std::string_view property) const;
    void remove(std::string_view property);

private:
    std::map<std::string_view, std::any> mData;
};
