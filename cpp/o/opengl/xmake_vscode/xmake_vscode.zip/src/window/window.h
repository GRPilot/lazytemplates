#pragma once

using winsize_t = unsigned short;

class Window;

class WindowManager {
    WindowManager() = default;
public:
    static WindowManager *instance();

    void add(Window *window);
    void remove(Window *window);
    Window *find(GLFWwindow *rawWindow) const;

private:
    std::vector<Window *> mWindows;
};

struct KeyHandler {
    using Method = std::function<void(GLFWwindow *)>;
    int action{};
    int key{};
    Method method{};
    KeyHandler(int action, int key, Method method)
        : action{ action }, key{ key }, method{ method } {}
};

class Window {
public:
    
    Window(const std::string &title, winsize_t width, winsize_t height);
    ~Window();

    void clear(float red, float green, float blue, float alpha) const;
    bool active() const;
    bool valid() const;
    void update() const;
    void addHandler(const KeyHandler &handler);

    bool operator==(const Window &other) const;
    bool operator==(const GLFWwindow *other) const;

private:
    GLFWwindow *mWin;
    std::vector<KeyHandler> mHandlers;

    static void keyEvent(GLFWwindow *win, int key, int scancode, int action, int mode);
    static void resizeEvent(GLFWwindow *win, int width, int height);
};

