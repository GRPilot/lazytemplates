#include "deps.h"

#include "window.h"

Window::Window(const std::string &title, winsize_t width, winsize_t height)
    : mWin{ glfwCreateWindow(width, height, title.c_str(), nullptr, nullptr) } {
    WindowManager::instance()->add(this);
    glfwMakeContextCurrent(mWin);
    glfwSetFramebufferSizeCallback(mWin, Window::resizeEvent);
    glfwSetKeyCallback(mWin, Window::keyEvent);
}

Window::~Window() {
    WindowManager::instance()->remove(this);
    glfwDestroyWindow(mWin);
}

void Window::clear(float red, float green, float blue, float alpha) const {
    glClearColor(red, green, blue, alpha);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
}

bool Window::active() const {
    return !glfwWindowShouldClose(mWin);
}

bool Window::valid() const {
    return nullptr != mWin;
}

void Window::update() const {
    glfwSwapBuffers(mWin);
    glfwPollEvents();
}

void Window::addHandler(const KeyHandler &handler) {
    mHandlers.emplace_back(handler.action, handler.key, handler.method);
}

void Window::keyEvent(GLFWwindow *win, int key, int scancode, int action, int mode) {
    Window *This{ WindowManager::instance()->find(win) };
    if(nullptr == This) {
        return;
    }
    for(auto &handler : This->mHandlers) {
        if(action != handler.action) {
            continue;
        }
        if(key == handler.key && handler.method) {
            handler.method(win);
        }
    }
}

void Window::resizeEvent(GLFWwindow *win, int width, int height) {
    glViewport(0, 0, width, height);
}

bool Window::operator==(const Window &other) const {
    if(this == &other) {
        return true;
    }

    if(!valid() || !other.valid()) {
        return false;
    }

    return this->mWin == other.mWin;
}

bool Window::operator==(const GLFWwindow *other) const {
    if(other == nullptr) {
        return false;
    }
    return this->mWin == other;
}

WindowManager *WindowManager::instance() {
    static WindowManager manager;
    return &manager;
}

void WindowManager::add(Window *window) {
    if(nullptr == window) {
        return;
    }

    auto found{ std::find(mWindows.begin(), mWindows.end(), window) };
    if(found == mWindows.end()) {
        mWindows.push_back(window);
    }
}

void WindowManager::remove(Window *window) {
    if(nullptr == window) {
        return;
    }
    auto found{ std::find(mWindows.begin(), mWindows.end(), window) };
    if(found != mWindows.end()) {
        mWindows.erase(found);
    }
}

Window *WindowManager::find(GLFWwindow *rawWindow) const {
    if(nullptr == rawWindow) {
        return nullptr;
    }

    auto found { std::find_if(mWindows.begin(), mWindows.end(),
        [raw = rawWindow](const Window *win) -> bool {
            return *win == raw;
        }
    )};
    if(found == mWindows.end()) {
        return nullptr;
    }
    return *found;
}
