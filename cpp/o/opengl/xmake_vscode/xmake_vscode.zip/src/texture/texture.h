#pragma once

class Texture {
public:
    explicit Texture(const std::string &path);
    ~Texture();

    void bind();
    bool valid() const;

    operator unsigned() const;

private:
    unsigned mId;
    bool mValid;
};
