#include "deps.h"

#include "window.h"
#include "model.h"
#include "shader.h"
#include "texture.h"
#include "mash.h"
#include "vertex.h"
#include "renderer.h"
#include "render_context.h"

int main() {
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

    Window window{ "OpenGL | textures", 800, 600 };
    if(!window.valid()) {
        std::cerr << "Error while creating glfw window\n";
        return -1;
    }
    window.addHandler({GLFW_PRESS, GLFW_KEY_ESCAPE, [](GLFWwindow *win) {
        glfwSetWindowShouldClose(win, GLFW_TRUE);
    }});

    if(!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress)) {
        std::cout << "Error while initializing GLAD\n";
        return -1;
    }

    Vertices vertices {{
        Vertex{ { -0.5f, -0.5f, 0.0f }, { 0.0f, 1.0f, 0.0f, 1.0f }, { 0.0f, 0.0f } },
        Vertex{ { -0.5f,  0.5f, 0.0f }, { 1.0f, 0.0f, 0.0f, 1.0f }, { 1.0f, 0.0f } },
        Vertex{ {  0.5f,  0.5f, 0.0f }, { 1.0f, 1.0f, 1.0f, 1.0f }, { 1.0f, 1.0f } },
        Vertex{ {  0.5f, -0.5f, 0.0f }, { 0.0f, 0.0f, 1.0f, 1.0f }, { 0.0f, 1.0f } }
    }};

    std::vector<unsigned> indices {
        0, 1, 3,
        2, 1, 3
    };

    Model triangle{
        std::make_shared<Mash>(vertices, indices),
        std::make_shared<Shader>(),
        std::make_shared<Texture>("res/textures/marble.jpg")
    };

    RenderContext defaultCtx;
    defaultCtx.state = RenderContext::State::Enabled;
    Renderer renderer;

    while(window.active()) {
        window.clear(.5f, .2f, .6f, 1.f);

        triangle.draw(renderer, defaultCtx);

        window.update();
    }

    glfwTerminate();
}
