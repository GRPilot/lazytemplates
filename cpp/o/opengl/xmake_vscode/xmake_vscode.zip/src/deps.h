#pragma once

// OpenGL
#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <stb_image.h>
#include <glm/glm.hpp>


// Standard
#include <string_view>
#include <functional>
#include <algorithm>
#include <iostream>
#include <optional>
#include <fstream>
#include <cassert>
#include <string>
#include <vector>
#include <memory>
#include <map>
#include <any>
