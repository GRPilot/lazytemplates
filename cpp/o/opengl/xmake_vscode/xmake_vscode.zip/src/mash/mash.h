#pragma once

class Vertex;
class Vertices;

class Mash {
public:
    Mash();
    Mash(const Vertices &vertices);
    Mash(const Vertices &vertices, const std::vector<unsigned> &indices);

    void load(const Vertices &vertices);
    void load(const std::vector<unsigned> &indices);
    void load(const Vertices &vertices, const std::vector<unsigned> &indices);

    void bind() const;
    void unbind() const;

    bool hasIndices() const;
    size_t indices() const;
    size_t vertices() const;

private:
    size_t mIndices{};
    size_t mVertices{};

    enum class BufferType {
        VAO, VBO, EBO
    };

    std::map<BufferType, GLuint> mBuffers;

    void resetBuffer(BufferType type);
    void loadBuffer(BufferType type, GLenum target, size_t size, const GLubyte *data);
};

