#include "deps.h"

#include "mash.h"
#include "vertex.h"
#include "shader.h"

Mash::Mash() {
    mBuffers[BufferType::VAO] = 0u;
    glGenVertexArrays(1, &mBuffers[BufferType::VAO]);
}

Mash::Mash(const Vertices &vertices) 
    : Mash{} {
    load(vertices);
}

Mash::Mash(const Vertices &vertices, const std::vector<unsigned> &indices) 
    : Mash{ vertices } {
    load(indices);
}

void Mash::load(const Vertices &vertices) {
    if(vertices.empty()) {
        return;
    }
    mVertices = vertices.count();

    bind();
    resetBuffer(BufferType::VBO);
    loadBuffer(BufferType::VBO, GL_ARRAY_BUFFER, vertices.length(),
               reinterpret_cast<const GLubyte *>(vertices.raw().data()));

    glVertexAttribPointer(Position::Position, VertexInfo::Count::pos, GL_FLOAT, GL_FALSE,
                          VertexInfo::stride, (void *)VertexInfo::Offset::pos);
    glEnableVertexAttribArray(Position::Position);

    glVertexAttribPointer(Position::Color, VertexInfo::Count::clr, GL_FLOAT, GL_FALSE,
                          VertexInfo::stride, (void *)VertexInfo::Offset::clr);
    glEnableVertexAttribArray(Position::Color);

    glVertexAttribPointer(Position::TextureCoordinates, VertexInfo::Count::clr, GL_FLOAT, GL_FALSE,
                          VertexInfo::stride, (void *)VertexInfo::Offset::tex);
    glEnableVertexAttribArray(Position::TextureCoordinates);

    unbind();
}

void Mash::load(const std::vector<unsigned> &indices) {
    if(indices.empty()) {
        return;
    }
    mIndices = indices.size();

    bind();
    resetBuffer(BufferType::EBO);
    loadBuffer(BufferType::EBO, GL_ELEMENT_ARRAY_BUFFER,
               sizeof(float) * indices.size(),
               reinterpret_cast<const GLubyte *>(indices.data()));
    unbind();
}

void Mash::load(const Vertices &vertices, const std::vector<unsigned> &indices) {
    load(vertices);
    load(indices);
}

void Mash::bind() const {
    glBindVertexArray(mBuffers.at(BufferType::VAO));
}

void Mash::unbind() const {
    glBindVertexArray(0);
}

bool Mash::hasIndices() const {
    return mIndices != 0;
}

size_t Mash::indices() const {
    return mIndices;
}

size_t Mash::vertices() const {
    return mVertices;
}

void Mash::resetBuffer(BufferType type) {
    if(auto found{ mBuffers.find(type) }; found != mBuffers.end()) {
        glDeleteBuffers(1, &(found->second));
        found->second = 0u;
    } else {
        mBuffers[type] = 0u;
    }
}

void Mash::loadBuffer(BufferType type, GLenum target, size_t size, const GLubyte *data) {
    if(nullptr == data) {
        return;
    }

    auto &buffer{ mBuffers[type] };

    glGenBuffers(1, &buffer);
    glBindBuffer(target, buffer);
    glBufferData(target, size, data, GL_STATIC_DRAW);
}
