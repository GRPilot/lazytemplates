add_rules("mode.debug", "mode.release")

if is_mode("debug") then
    set_symbols("debug")
    set_optimize("none")
    add_defines("DEBUG")
elseif is_mode("release") then
    set_symbols("hidden")
    set_strip("all")
end

add_requires("glfw", "glad", "glm", "stb")

target("opengl-xmake")
    set_kind("binary")
    set_installdir(".")
    set_languages("c++17")

    add_packages("glfw", "glad", "glm", "stb")
    on_load(function (target) 
        target:add("includedirs", "src")
        for _, dir in ipairs(os.dirs("src/**")) do
            -- print("Loading "..tostring(dir))
            target:add("includedirs", dir)
        end
    end)

    add_headerfiles("src/**.h")
    add_files("src/**.cpp")
